package com.alibou.book.book;

import com.alibou.book.file.FileUtils;
import com.alibou.book.history.BookTransactionHistory;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class BookMapper {

    public Document toDocument(Book book) {
        String bookContent = """
                Title: %s
                Author: %s
                Synopsis: %s
                """.formatted(book.getTitle(), book.getAuthorName(), book.getSynopsis());

        Map<String, Object> metadata = Map.of(
                "bookId", book.getId(),
                "isbn", book.getIsbn(),
                "archived", book.isArchived(),
                "shareable", book.isShareable()
        );

        return new Document(bookContent, metadata);    }

    public Book toBook(BookRequest request) {
        return Book.builder()
                .id(request.id())
                .title(request.title())
                .isbn(request.isbn())
                .authorName(request.authorName())
                .synopsis(request.synopsis())
                .archived(false)
                .shareable(request.shareable())
                .build();
    }

    public BookResponse toBookResponse(Book book) {
        return BookResponse.builder()
                .id(book.getId())
                .title(book.getTitle())
                .authorName(book.getAuthorName())
                .isbn(book.getIsbn())
                .synopsis(book.getSynopsis())
                .rate(book.getRate())
                .archived(book.isArchived())
                .shareable(book.isShareable())
                // .owner(book.getOwner().fullName())
                .cover(FileUtils.readFileFromLocation(book.getBookCover()))
                .build();
    }

    public BorrowedBookResponse toBorrowedBookResponse(BookTransactionHistory history) {
        return BorrowedBookResponse.builder()
                .id(history.getBook().getId())
                .title(history.getBook().getTitle())
                .authorName(history.getBook().getAuthorName())
                .isbn(history.getBook().getIsbn())
                .rate(history.getBook().getRate())
                .returned(history.isReturned())
                .returnApproved(history.isReturnApproved())
                .build();
    }
}
