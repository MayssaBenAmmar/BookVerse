import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { KeycloakService } from '../../../../services/keycloak/keycloak.service';
import { UserProfile } from '../../../../services/keycloak/user-profile';
import { Subscription, interval } from 'rxjs';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, OnDestroy, AfterViewInit {
  userProfile: UserProfile | undefined;
  loading = false;
  isCurrentUser = true;
  viewUsername: string | null = null;
  errorMessage: string | null = null;
  displayName: string = 'User'; // Default value
  profileImageSrc: string = 'https://via.placeholder.com/150'; // Default image

  formattedUsername: string = '';
  formattedFullName: string = '';
  formattedEmail: string = '';

  // DOM fix interval subscription
  private fixIntervalSubscription: Subscription | undefined;
  private routeSubscription: Subscription | undefined;

  constructor(
    private keycloakService: KeycloakService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.routeSubscription = this.route.paramMap.subscribe(params => {
      const username = params.get('username');
      this.viewUsername = username;

      if (this.viewUsername) {
        console.log('Viewing profile for user:', this.viewUsername);
        this.displayName = this.formatUsername(this.viewUsername);
        this.formattedUsername = this.displayName;

        const currentUsername = this.keycloakService.username || '';
        this.isCurrentUser = this.viewUsername === currentUsername;

        if (this.isCurrentUser) {
          this.userProfile = this.keycloakService.profile;
          const username = this.keycloakService.username || '';
          this.displayName = this.formatUsername(username);
          this.formattedUsername = this.displayName;
          this.formatProfileData();
          this.loadProfileImage();
        } else {
          this.loading = true;
          this.loadOtherUserProfile(this.viewUsername);
        }
      } else {
        this.userProfile = this.keycloakService.profile;
        const username = this.keycloakService.username || '';
        this.displayName = this.formatUsername(username);
        this.formattedUsername = this.displayName;
        this.formatProfileData();
        this.loadProfileImage();
      }
    });
  }

  ngAfterViewInit() {
    // Start an interval to repeatedly fix the DOM elements
    // This will handle cases where elements are dynamically loaded or changed
    this.fixIntervalSubscription = interval(200).pipe(
      take(15) // Run 15 times (3 seconds total) to ensure all elements are fixed
    ).subscribe(() => {
      this.fixAllDOMElements();
    });
  }

  ngOnDestroy() {
    if (this.routeSubscription) {
      this.routeSubscription.unsubscribe();
    }
    if (this.fixIntervalSubscription) {
      this.fixIntervalSubscription.unsubscribe();
    }
  }

  // More aggressive DOM fixing function
  private fixAllDOMElements(): void {
    if (!this.viewUsername || this.isCurrentUser || !this.formattedUsername) return;

    try {
      // Generate UUID pattern based on the actual username
      const uuidParts = this.viewUsername.split('-');
      if (uuidParts.length < 2) return;

      const firstPart = uuidParts[0];

      // Try various patterns to catch all UUID formats
      const patterns = [
        new RegExp(`User\\s+${firstPart}.*?('s|$)`, 'gi'),
        new RegExp(`${firstPart}(-[0-9a-f]{4}){3}-[0-9a-f]{12}`, 'gi'),
        new RegExp(`User\\s+${firstPart}.*?@example\\.com`, 'gi')
      ];

      // Fix document title
      if (document.title.includes(firstPart)) {
        document.title = `${this.formattedUsername}'s Profile - Book Network`;
      }

      // Target specific elements by their class/tag names
      const specificSelectors = [
        '.profile-title',
        '.book-spine h2',
        '.books-title',
        'h3.profile-title',
        '.username-display',
        '.user-profile-header',
        '.user-email-display'
      ];

      // Look for elements with these specific selectors
      specificSelectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
          const text = element.textContent || '';
          if (text.includes(firstPart)) {
            patterns.forEach(pattern => {
              element.textContent = text.replace(pattern,
                (match) => match.includes('@')
                  ? `${this.formattedUsername}@example.com`
                  : (match.includes("'s")
                    ? `${this.formattedUsername}'s`
                    : this.formattedUsername)
              );
            });
          }
        });
      });

      // Find all text nodes in the document that contain the UUID
      const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: function(node) {
            return node.nodeValue && node.nodeValue.includes(firstPart)
              ? NodeFilter.FILTER_ACCEPT
              : NodeFilter.FILTER_REJECT;
          }
        }
      );

      // Walk through all matching text nodes and replace the UUID text
      const nodes = [];
      let currentNode;
      while (currentNode = walker.nextNode()) {
        nodes.push(currentNode);
      }

      // Replace text in found nodes
      nodes.forEach(node => {
        let newText = node.nodeValue || '';
        patterns.forEach(pattern => {
          newText = newText.replace(pattern,
            (match) => match.includes('@')
              ? `${this.formattedUsername}@example.com`
              : (match.includes("'s")
                ? `${this.formattedUsername}'s`
                : this.formattedUsername)
          );
        });
        node.nodeValue = newText;
      });

    } catch (error) {
      console.error('Error fixing DOM elements:', error);
    }
  }

  private formatProfileData(): void {
    if (!this.userProfile) return;

    // Format full name
    if (this.userProfile.firstName || this.userProfile.lastName) {
      let firstName = this.userProfile.firstName || '';
      if (this.looksLikeUUID(firstName)) {
        firstName = 'User';
      }

      let lastName = this.userProfile.lastName || '';
      if (this.looksLikeUUID(lastName)) {
        lastName = '';
      }

      this.formattedFullName = `${firstName} ${lastName}`.trim();
      if (!this.formattedFullName) {
        this.formattedFullName = 'User';
      }
    } else {
      this.formattedFullName = 'User';
    }

    // Format email
    if (this.userProfile.email) {
      if (this.looksLikeUUID(this.userProfile.email.split('@')[0])) {
        this.formattedEmail = `${this.displayName}@example.com`;
      } else {
        this.formattedEmail = this.userProfile.email;
      }
    } else {
      this.formattedEmail = this.displayName + '@example.com';
    }
  }

  // Format a UUID-style username into something more readable
  private formatUsername(username: string): string {
    if (!username) {
      return 'User';
    }

    // Check if it's a UUID-style username (contains dashes and is long)
    if (username.includes('-') && username.length > 20) {
      // Return a shorter version
      return `User ${username.split('-')[0]}`;
    }

    // Check if it's an email
    if (username.includes('@')) {
      return username.split('@')[0];
    }

    // Otherwise return as is
    return username;
  }

  // Check if a string looks like a UUID
  private looksLikeUUID(str: string): boolean {
    if (!str) return false;
    return (str.includes('-') && str.length > 20) || str.length > 30;
  }

  editProfile() {
    if (!this.isCurrentUser) return;

    const authServerUrl = this.keycloakService.keycloakInstance.authServerUrl;
    const realm = this.keycloakService.keycloakInstance.realm;

    if (authServerUrl && realm) {
      window.location.href = `${authServerUrl}/realms/${realm}/account`;
    } else {
      console.error('Unable to determine Keycloak URL');
      this.errorMessage = 'Unable to access account settings';
    }
  }

  goBack() {
    this.router.navigate(['/books']);
  }

  private loadOtherUserProfile(username: string) {
    console.log('Loading profile for user:', username);

    setTimeout(() => {
      if (this.looksLikeUUID(username)) {
        this.userProfile = {
          username: username,
          firstName: 'User',
          lastName: '',
          email: `${username}@example.com`,
        };
      } else if (username.includes('@')) {
        const emailPrefix = username.split('@')[0];

        this.userProfile = {
          username: username,
          firstName: emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1),
          lastName: '',
          email: username,
        };
      } else {
        this.userProfile = {
          username: username,
          firstName: username.charAt(0).toUpperCase() + username.slice(1),
          lastName: '',
          email: `${username}@example.com`,
        };
      }

      this.formatProfileData();
      this.loading = false;

      // Give the DOM time to update, then fix the elements
      setTimeout(() => {
        this.fixAllDOMElements();
      }, 100);
    }, 1000);
  }

  triggerFileInput(): void {
    const fileInput = document.getElementById('profile-image-upload');
    if (fileInput) {
      fileInput.click();
    }
  }

  onProfileImageSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();

      reader.onload = (e: any) => {
        this.profileImageSrc = e.target.result;

        const username = this.keycloakService.username || 'default-user';
        localStorage.setItem(`profileImage_${username}`, this.profileImageSrc);
      };

      reader.readAsDataURL(file);
    }
  }

  loadProfileImage(): void {
    const username = this.keycloakService.username || 'default-user';
    const savedImage = localStorage.getItem(`profileImage_${username}`);

    if (savedImage) {
      this.profileImageSrc = savedImage;
    }
  }
}
